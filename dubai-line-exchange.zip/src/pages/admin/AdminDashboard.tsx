import { useState, useEffect } from 'react';
import { Card } from '../../components/UI';
import { Users, ArrowUpCircle, ArrowDownCircle, Activity, TrendingUp, Settings, ChevronRight } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, query, onSnapshot, getDocs, where } from 'firebase/firestore';
import { formatCurrency, cn } from '../../lib/utils';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalDeposits: 0,
    totalWithdrawals: 0,
    pendingDeposits: 0,
    pendingWithdrawals: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // This is a simplified count. For large apps, use aggregation counters or Cloud Functions.
    const fetchData = async () => {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const fundSnap = await getDocs(collection(db, 'fundRequests'));
        const withdrawSnap = await getDocs(collection(db, 'withdrawRequests'));

        const approvedDeposits = fundSnap.docs
          .filter(d => d.data().status === 'approved')
          .reduce((acc, curr) => acc + (curr.data().amount || 0), 0);

        const approvedWithdrawals = withdrawSnap.docs
          .filter(d => d.data().status === 'approved')
          .reduce((acc, curr) => acc + (curr.data().amount || 0), 0);

        setStats({
          totalUsers: usersSnap.size,
          totalDeposits: approvedDeposits,
          totalWithdrawals: approvedWithdrawals,
          pendingDeposits: fundSnap.docs.filter(d => d.data().status === 'pending').length,
          pendingWithdrawals: withdrawSnap.docs.filter(d => d.data().status === 'pending').length
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'stats');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const statCards = [
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'text-cyan-500' },
    { label: 'Total Deposits', value: formatCurrency(stats.totalDeposits), icon: ArrowUpCircle, color: 'text-emerald-500' },
    { label: 'Total Withdrawals', value: formatCurrency(stats.totalWithdrawals), icon: ArrowDownCircle, color: 'text-rose-500' },
    { label: 'Pending Deposits', value: stats.pendingDeposits, icon: Activity, color: 'text-amber-500' },
    { label: 'Pending Withdrawals', value: stats.pendingWithdrawals, icon: TrendingUp, color: 'text-purple-500' },
  ];

  if (loading) return <div className="p-8 text-cyan-500 animate-pulse">Loading analytics...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Admin Overview</h1>
        <div className="text-xs text-slate-500 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
          Live Data
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((card, i) => (
          <Card key={i} className="group hover:border-cyan-500/50 transition-all">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">{card.label}</p>
                <h2 className="text-3xl font-bold text-white tabular-nums">{card.value}</h2>
              </div>
              <div className={`p-3 rounded-xl bg-slate-900 border border-slate-800 group-hover:bg-slate-800 ${card.color}`}>
                <card.icon className="w-6 h-6" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest px-1">Quick Actions</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
             {[
               { label: 'Manage Users', path: '/admin/users', icon: Users, color: 'text-cyan-500' },
               { label: 'Game Settings', path: '/admin/games', icon: Settings, color: 'text-pink-500' },
               { label: 'View Bets', path: '/admin/bets', icon: Activity, color: 'text-purple-500' },
               { label: 'View Deposits', path: '/admin/deposits', icon: ArrowUpCircle, color: 'text-emerald-500' },
               { label: 'View Withdrawals', path: '/admin/withdrawals', icon: ArrowDownCircle, color: 'text-rose-500' },
             ].map((action, i) => (
               <Link key={i} to={action.path}>
                 <Card className="p-4 hover:bg-slate-800 transition-colors flex items-center justify-between group">
                   <div className="flex items-center gap-3">
                      <action.icon className={cn("w-5 h-5", action.color)} />
                      <span className="text-sm font-bold text-white">{action.label}</span>
                   </div>
                   <ChevronRight className="w-4 h-4 text-slate-700 group-hover:text-slate-400 group-hover:translate-x-1 transition-all" />
                 </Card>
               </Link>
             ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest px-1">Platform Status</h3>
          <Card className="min-h-[200px] flex flex-col justify-center border-dashed p-6">
             <div className="flex items-center gap-3 mb-4">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold text-white uppercase tracking-widest">Systems Operational</span>
             </div>
             <p className="text-slate-500 text-xs leading-relaxed">
               All exchange parameters are currently synchronized with the main ledger. Real-time settlement is active for all trading lines.
             </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
