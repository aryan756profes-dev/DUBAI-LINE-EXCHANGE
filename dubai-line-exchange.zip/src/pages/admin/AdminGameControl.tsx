import { useState, useEffect } from 'react';
import { Card, Button } from '../../components/UI';
import { Settings, Play, Pause, Save, Clock, Trophy, Hash, Palette } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { doc, onSnapshot, updateDoc, setDoc, getDocs, collection, query, where, runTransaction, increment, serverTimestamp } from 'firebase/firestore';
import { cn } from '../../lib/utils';

export default function AdminGameControl() {
  const [games, setGames] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Game Settings State
  const [numberSettings, setNumberSettings] = useState<any>(null);
  const [colorSettings, setColorSettings] = useState<any>(null);
  
  // Manual Result State
  const [manualNumber, setManualNumber] = useState('');
  const [manualColor, setManualColor] = useState('');
  const [numberScheduleTime, setNumberScheduleTime] = useState('');
  const [colorScheduleTime, setColorScheduleTime] = useState('');
  const [scheduledResults, setScheduledResults] = useState<any[]>([]);

  useEffect(() => {
    // Listen to scheduled results
    const q = query(collection(db, 'results'), where('isDeclared', '==', false));
    const unsubResults = onSnapshot(q, (snap) => {
       setScheduledResults(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a: any, b: any) => a.resultTime - b.resultTime));
    });

    // Listen to game settings
    const unsubNumber = onSnapshot(doc(db, 'settings', 'numberGame'), (snap) => {
      if (snap.exists()) setNumberSettings(snap.data());
      else {
        // Init if not exists
        setDoc(doc(db, 'settings', 'numberGame'), {
          enabled: true,
          multiplier: 10,
          manualResult: null,
          updatedAt: serverTimestamp()
        });
      }
    });

    const unsubColor = onSnapshot(doc(db, 'settings', 'colorGame'), (snap) => {
      if (snap.exists()) setColorSettings(snap.data());
      else {
        // Init if not exists
        setDoc(doc(db, 'settings', 'colorGame'), {
          enabled: true,
          multiplier: 10,
          manualResult: null,
          updatedAt: serverTimestamp()
        });
      }
      setLoading(false);
    });

    return () => {
      unsubResults();
      unsubNumber();
      unsubColor();
    };
  }, []);

  const updateGameStatus = async (gameId: string, enabled: boolean) => {
    try {
      await updateDoc(doc(db, 'settings', `${gameId}Game`), {
        enabled,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `settings/${gameId}Game`);
    }
  };

  const setGameManualResult = async (gameId: string, result: any, timeStr: string) => {
    try {
      if (!timeStr) {
        alert("Please select a date and time to schedule the result.");
        return;
      }

      const resultTime = new Date(timeStr);
      if (isNaN(resultTime.getTime())) {
        alert("Invalid date/time selected.");
        return;
      }

      if (resultTime < new Date()) {
        alert("You cannot schedule a result in the past.");
        return;
      }

      const sessionId = `${gameId}-${resultTime.getTime()}`;

      // 2. Set result in results collection with isDeclared: false
      const resultValue = gameId === 'number' ? parseInt(result) : result;
      
      const resultData = {
        gameType: gameId,
        resultValue: resultValue,
        sessionId,
        resultTime: resultTime.getTime(),
        isDeclared: false,
        timestamp: serverTimestamp()
      };
      
      await setDoc(doc(db, 'results', sessionId), resultData);

      alert(`Result for ${gameId} scheduled for ${resultTime.toLocaleString()}! It will be revealed automatically.`);
      if (gameId === 'number') {
        setManualNumber('');
        setNumberScheduleTime('');
      }
      if (gameId === 'color') {
        setManualColor('');
        setColorScheduleTime('');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `results/${gameId}`);
    }
  };

  const clearManualResult = async (gameId: string) => {
    try {
      await updateDoc(doc(db, 'settings', `${gameId}Game`), {
        manualResult: null,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `settings/${gameId}Game`);
    }
  };

  if (loading) return <div className="p-8 text-cyan-500 animate-pulse">Loading game controls...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Game Management</h1>
        <Settings className="w-6 h-6 text-slate-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Number Exchange Control */}
        <Card className={cn("transition-all border-l-4", numberSettings?.enabled ? "border-l-cyan-500" : "border-l-rose-500")}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-cyan-500/10 rounded-lg text-cyan-500">
                <Hash className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white uppercase tracking-tight text-sm">Number Exchange</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Payout: 90x</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              size="sm"
              className={numberSettings?.enabled ? "text-rose-500" : "text-emerald-500"}
              onClick={() => updateGameStatus('number', !numberSettings?.enabled)}
            >
              {numberSettings?.enabled ? <><Pause className="w-3 h-3 mr-1" /> Disable</> : <><Play className="w-3 h-3 mr-1" /> Enable</>}
            </Button>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Schedule Result</label>
              <div className="flex flex-col gap-3">
                <div className="flex gap-2">
                  <input 
                    type="number"
                    min="1"
                    max="99"
                    placeholder="1-99"
                    value={manualNumber}
                    onChange={(e) => setManualNumber(e.target.value)}
                    className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-cyan-500"
                  />
                  <input 
                    type="datetime-local"
                    value={numberScheduleTime}
                    onChange={(e) => setNumberScheduleTime(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-cyan-500"
                  />
                </div>
                <Button 
                  size="sm" 
                  disabled={!manualNumber || !numberScheduleTime}
                  className="w-full"
                  onClick={() => setGameManualResult('number', parseInt(manualNumber), numberScheduleTime)}
                >
                  Schedule Result
                </Button>
              </div>
              {numberSettings?.manualResult && (
                <div className="mt-3 flex items-center justify-between bg-cyan-500/10 border border-cyan-500/20 p-2 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-cyan-500" />
                    <span className="text-xs font-bold text-cyan-500 uppercase tracking-widest">Active Manual: {numberSettings.manualResult}</span>
                  </div>
                  <button onClick={() => clearManualResult('number')} className="text-[10px] text-slate-500 hover:text-white uppercase font-black">Clear</button>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* Color X-Line Control */}
        <Card className={cn("transition-all border-l-4", colorSettings?.enabled ? "border-l-pink-500" : "border-l-rose-500")}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-pink-500/10 rounded-lg text-pink-500">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white uppercase tracking-tight text-sm">Color X-Line</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Payout: 9x (Orange: 15x)</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              size="sm"
              className={colorSettings?.enabled ? "text-rose-500" : "text-emerald-500"}
              onClick={() => updateGameStatus('color', !colorSettings?.enabled)}
            >
              {colorSettings?.enabled ? <><Pause className="w-3 h-3 mr-1" /> Disable</> : <><Play className="w-3 h-3 mr-1" /> Enable</>}
            </Button>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Schedule Result</label>
              <div className="flex flex-col gap-3">
                <div className="flex gap-2">
                  <select 
                    value={manualColor}
                    onChange={(e) => setManualColor(e.target.value)}
                    className="w-32 bg-slate-900 border border-slate-800 rounded-lg px-2 py-2 text-white text-sm outline-none focus:border-pink-500"
                  >
                    <option value="">Color</option>
                    {['Green', 'Navy', 'Pink', 'Red', 'Grey', 'Brown', 'Tan', 'Yellow', 'White', 'Orange'].map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <input 
                    type="datetime-local"
                    value={colorScheduleTime}
                    onChange={(e) => setColorScheduleTime(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-pink-500"
                  />
                </div>
                <Button 
                  size="sm" 
                  disabled={!manualColor || !colorScheduleTime}
                  className="w-full"
                  onClick={() => setGameManualResult('color', manualColor, colorScheduleTime)}
                >
                  Schedule Result
                </Button>
              </div>
              {colorSettings?.manualResult && (
                <div className="mt-3 flex items-center justify-between bg-pink-500/10 border border-pink-500/20 p-2 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-pink-500" />
                    <span className="text-xs font-bold text-pink-500 uppercase tracking-widest">Active Manual: {colorSettings.manualResult}</span>
                  </div>
                  <button onClick={() => clearManualResult('color')} className="text-[10px] text-slate-500 hover:text-white uppercase font-black">Clear</button>
                </div>
              )}
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 bg-slate-950 border-cyan-500/20">
         <div className="flex items-center gap-2 mb-6">
            <Clock className="w-5 h-5 text-cyan-500" />
            <h2 className="text-xl font-bold text-white tracking-tight">Scheduled Results</h2>
         </div>
         {scheduledResults.length === 0 ? (
           <p className="text-sm text-slate-500 italic">No results currently scheduled.</p>
         ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
             {scheduledResults.map((result) => (
               <div key={result.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col gap-2">
                 <div className="flex justify-between items-center">
                   <span className={cn("text-xs font-black uppercase tracking-widest px-2 py-1 rounded-md", result.gameType === 'number' ? 'bg-cyan-500/10 text-cyan-500' : 'bg-pink-500/10 text-pink-500')}>
                     {result.gameType === 'number' ? 'Number Exchange' : 'Color X-Line'}
                   </span>
                   <span className="text-white font-black text-lg">{result.resultValue}</span>
                 </div>
                 <div className="text-xs font-bold text-slate-400 mt-2 flex items-center gap-1">
                   <Clock className="w-3 h-3" />
                   {new Date(result.resultTime).toLocaleString()}
                 </div>
               </div>
             ))}
           </div>
         )}
      </Card>
    </div>
  );
}
