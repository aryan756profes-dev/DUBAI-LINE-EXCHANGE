import { useState, useEffect } from 'react';
import { Card, Button } from '../../components/UI';
import { ArrowDownCircle, Check, X, Clock, User, Filter, AlertCircle } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, query, onSnapshot, doc, runTransaction, serverTimestamp, orderBy, increment } from 'firebase/firestore';
import { formatCurrency, cn } from '../../lib/utils';

export default function AdminWithdrawals() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');

  useEffect(() => {
    const q = query(collection(db, 'withdrawRequests'), orderBy('createdAt', 'desc'), limit(200));
    const unsubscribe = onSnapshot(q, (snap) => {
      setRequests(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'withdrawRequests');
    });
    return () => unsubscribe();
  }, []);

  const handleApprove = async (requestId: string) => {
    try {
      await runTransaction(db, async (transaction) => {
        const requestRef = doc(db, 'withdrawRequests', requestId);
        transaction.update(requestRef, {
          status: 'approved',
          processedAt: serverTimestamp()
        });
      });
      alert('Withdrawal approved! Make sure to send funds manually.');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `withdrawRequests/${requestId}`);
    }
  };

  const handleReject = async (request: any) => {
    try {
      await runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', request.uid);
        const requestRef = doc(db, 'withdrawRequests', request.id);
        
        const userSnap = await transaction.get(userRef);
        if (!userSnap.exists()) throw new Error('User not found');
        
        const currentBalance = userSnap.data().balance || 0;
        
        // Refund the amount to main balance
        transaction.update(userRef, {
          balance: increment(request.amount),
          updatedAt: serverTimestamp()
        });
        
        transaction.update(requestRef, {
          status: 'rejected',
          processedAt: serverTimestamp(),
          rejectionReason: 'Rejected by Administrator'
        });
      });
      alert('Withdrawal rejected and amount refunded.');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `withdrawRequests/${request.id}`);
    }
  };

  const filtered = requests.filter(r => filter === 'all' ? true : r.status === filter);

  if (loading) return <div className="p-8 text-cyan-500 animate-pulse">Loading withdrawals...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">Withdrawal Requests</h1>
        <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-1.5 rounded-lg text-xs font-bold transition-all capitalize",
                filter === f ? "bg-cyan-500 text-slate-950" : "text-slate-500 hover:text-slate-300"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4">
        {filtered.map((req) => (
          <Card key={req.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className={cn(
                  "p-3 rounded-xl border",
                  req.status === 'pending' ? "bg-amber-500/10 border-amber-500/20 text-amber-500" :
                  req.status === 'approved' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" :
                  "bg-red-500/10 border-red-500/20 text-red-500"
              )}>
                <ArrowDownCircle className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-xl text-white">{formatCurrency(req.amount)}</h3>
                  <span className="text-[10px] text-slate-500 font-mono">#{req.id.slice(-6)}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                  <User className="w-3 h-3 text-cyan-500" />
                  <span>UID: {req.uid}</span>
                  <span className="mx-1">•</span>
                  <Clock className="w-3 h-3" />
                  <span>{req.createdAt?.toDate?.()?.toLocaleString() || 'Just now'}</span>
                </div>
                <div className="mt-2 p-2 bg-slate-950 rounded border border-slate-800">
                   <p className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1">
                     <AlertCircle className="w-3 h-3" /> Payout Details
                   </p>
                   <p className="text-xs text-slate-300 mt-1">{req.method || 'Not specified'}: {req.accountDetails || 'N/A'}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {req.status === 'pending' ? (
                <>
                  <Button variant="secondary" size="sm" className="text-rose-500" onClick={() => handleReject(req)}>
                    <X className="w-4 h-4 mr-2" /> Reject
                  </Button>
                  <Button variant="primary" size="sm" onClick={() => handleApprove(req.id)}>
                    <Check className="w-4 h-4 mr-2" /> Approve
                  </Button>
                </>
              ) : (
                <div className={cn(
                  "px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border",
                  req.status === 'approved' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" : "bg-red-500/10 border-red-500/20 text-red-500"
                )}>
                  {req.status}
                </div>
              )}
            </div>
          </Card>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-20 text-slate-600 border border-dashed border-slate-800 rounded-2xl">
            <Filter className="w-12 h-12 mx-auto mb-4 opacity-10" />
            <p>No {filter !== 'all' ? filter : ''} withdrawal requests found</p>
          </div>
        )}
      </div>
    </div>
  );
}
