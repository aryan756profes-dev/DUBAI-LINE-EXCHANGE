import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Card, Button } from '../../components/UI';
import { Mail, Lock, ShieldAlert, ArrowRight } from 'lucide-react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password);
      const user = userCredential.user;

      // Check if user is actually an admin
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const userData = userDoc.data();
      if (!userDoc.exists() || (!userData?.isAdmin && userData?.role !== 'admin')) {
        // Sign out if not admin
        await auth.signOut();
        setError('Access Denied: Admin credentials required.');
        return;
      }

      navigate('/admin');
    } catch (err: any) {
      console.error("Admin login error:", err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError('Invalid admin credentials');
      } else if (err.code === 'auth/network-request-failed') {
        setError('Network error: Try opening in a new tab.');
      } else {
        setError('Authentication failed. Please check your connection.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="inline-flex p-4 rounded-3xl bg-slate-900 border border-slate-800 mb-6 shadow-xl">
            <ShieldAlert className="w-10 h-10 text-cyan-400" />
          </div>
          <h1 className="text-3xl font-black italic tracking-tighter text-white uppercase">Admin Portal</h1>
          <p className="text-slate-500 font-bold tracking-widest text-[10px] mt-2">DUBAI LINE EXCHANGE CENTRAL COMMAND</p>
        </div>

        <Card className="border-t-2 border-t-cyan-500">
          <form className="space-y-5" onSubmit={handleAdminLogin}>
            {error && (
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-xs font-bold flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Admin Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 focus:border-cyan-500 outline-none transition-all placeholder:text-slate-800 text-white"
                  placeholder="admin@example.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Secure Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 focus:border-cyan-500 outline-none transition-all placeholder:text-slate-800 text-white"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              loading={loading}
              className="w-full py-4 text-sm font-black shadow-lg shadow-cyan-500/20"
            >
              AUTHENTICATE COMMAND <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>
        </Card>

        <div className="mt-8 text-center">
          <Link to="/" className="text-slate-500 text-[10px] font-bold uppercase tracking-widest hover:text-cyan-400 transition-colors">
            ← Return to Public Terminal
          </Link>
        </div>
      </div>

      <p className="mt-12 text-slate-700 font-mono text-[9px] uppercase tracking-widest">
        DUBAI LINE SECURE INFRASTRUCTURE v4.0 // END-TO-END ENCRYPTED
      </p>
    </div>
  );
}
