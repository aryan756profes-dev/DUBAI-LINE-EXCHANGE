import { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, query, onSnapshot, orderBy, limit, doc, runTransaction } from 'firebase/firestore';
import { Card } from '../../components/UI';
import { formatCurrency, cn } from '../../lib/utils';
import { Search } from 'lucide-react';

export default function AdminBets() {
  const [bets, setBets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, 'bets'),
      orderBy('createdAt', 'desc'),
      limit(200)
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      const bList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBets(bList);
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'bets'));

    return () => unsubscribe();
  }, []);

  const filtered = bets.filter(b => 
    b.userId?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    b.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.gameType?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Bets & Payouts</h2>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input 
          type="text" 
          placeholder="Search by User ID, status, game..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 pl-10 pr-4 text-sm text-slate-200 outline-none focus:border-cyan-500 transition-colors"
        />
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-slate-800/50 text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-4 py-3 font-medium">User ID</th>
                <th className="px-4 py-3 font-medium">Game</th>
                <th className="px-4 py-3 font-medium">Selection</th>
                <th className="px-4 py-3 font-medium text-right">Amount</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Payout</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500">Loading bets...</td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500">No bets found.</td>
                </tr>
              ) : (
                filtered.map(bet => (
                  <tr key={bet.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="px-4 py-3 text-slate-400 text-xs">
                      {bet.createdAt?.toDate ? bet.createdAt.toDate().toLocaleString() : 'N/A'}
                    </td>
                    <td className="px-4 py-3 text-slate-300 text-xs">{bet.userId}</td>
                    <td className="px-4 py-3 text-slate-300 capitalize">{bet.gameType}</td>
                    <td className="px-4 py-3 text-cyan-400 font-bold">{bet.selectedValue}</td>
                    <td className="px-4 py-3 text-right text-slate-300">{formatCurrency(bet.amount)}</td>
                    <td className="px-4 py-3">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                        bet.status === 'win' ? "bg-emerald-500/20 text-emerald-400" :
                        bet.status === 'loss' ? "bg-rose-500/20 text-rose-400" :
                        "bg-slate-500/20 text-slate-400"
                      )}>
                        {bet.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      {bet.status === 'win' ? (
                        <span className="text-emerald-400 font-bold">+{formatCurrency(bet.winningAmount || 0)}</span>
                      ) : (
                        <span className="text-slate-500">-</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
