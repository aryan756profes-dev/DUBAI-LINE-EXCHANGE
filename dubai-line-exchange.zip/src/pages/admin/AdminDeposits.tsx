import { useState, useEffect } from 'react';
import { Card, Button } from '../../components/UI';
import { ArrowUpCircle, Check, X, Clock, User, Filter } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, query, onSnapshot, doc, runTransaction, serverTimestamp, orderBy, increment, limit } from 'firebase/firestore';
import { formatCurrency, cn } from '../../lib/utils';

export default function AdminDeposits() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');

  useEffect(() => {
    const q = query(collection(db, 'fundRequests'), orderBy('createdAt', 'desc'), limit(200));
    const unsubscribe = onSnapshot(q, (snap) => {
      setRequests(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'fundRequests');
    });
    return () => unsubscribe();
  }, []);

  const handleApprove = async (request: any) => {
    if (request.status !== 'pending') return;
    
    try {
      await runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', request.uid);
        const requestRef = doc(db, 'fundRequests', request.id);
        
        const userSnap = await transaction.get(userRef);
        if (!userSnap.exists()) throw new Error('User not found');
        
        const currentBalance = userSnap.data().balance || 0;
        
        console.log(`Approving deposit for user ${request.uid}: ₹${request.amount}`);
        transaction.update(userRef, {
          balance: increment(request.amount),
          depositAmount: increment(request.amount),
          requiredWager: increment(request.amount),
          updatedAt: serverTimestamp()
        });
        console.log(`Firestore updated: balance += ${request.amount}, requiredWager += ${request.amount}`);
        
        transaction.update(requestRef, {
          status: 'approved',
          processedAt: serverTimestamp()
        });
      });
      alert('Deposit approved successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `fundRequests/${request.id}`);
    }
  };

  const handleReject = async (requestId: string) => {
    try {
      await runTransaction(db, async (transaction) => {
        const requestRef = doc(db, 'fundRequests', requestId);
        transaction.update(requestRef, {
          status: 'rejected',
          processedAt: serverTimestamp()
        });
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `fundRequests/${requestId}`);
    }
  };

  const filtered = requests.filter(r => filter === 'all' ? true : r.status === filter);

  if (loading) return <div className="p-8 text-cyan-500 animate-pulse">Loading deposits...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">Deposit Requests</h1>
        <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-1.5 rounded-lg text-xs font-bold transition-all capitalize",
                filter === f ? "bg-cyan-500 text-slate-950" : "text-slate-500 hover:text-slate-300"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4">
        {filtered.map((req) => (
          <Card key={req.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className={cn(
                  "p-3 rounded-xl border shrink-0",
                  req.status === 'pending' ? "bg-amber-500/10 border-amber-500/20 text-amber-500" :
                  req.status === 'approved' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" :
                  "bg-red-500/10 border-red-500/20 text-red-500"
              )}>
                <ArrowUpCircle className="w-6 h-6" />
              </div>
              <div className="space-y-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-xl text-white">{formatCurrency(req.amount)}</h3>
                    <span className="text-[10px] text-slate-500 font-mono">#{req.id.slice(-6)}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                    <span className="flex items-center gap-1"><User className="w-3 h-3 text-cyan-500" /> {req.username || req.uid}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {req.createdAt?.toDate?.()?.toLocaleString() || 'Just now'}</span>
                  </div>
                </div>

                {req.transactionId && (
                  <div className="bg-slate-950 border border-slate-800 rounded-lg p-2 flex items-center justify-between gap-4">
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none mb-1">Transaction ID</p>
                      <p className="text-xs font-mono text-cyan-400">{req.transactionId}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 text-[10px]" 
                      onClick={() => {
                        navigator.clipboard.writeText(req.transactionId);
                        alert('Transaction ID copied!');
                      }}
                    >
                      COPY
                    </Button>
                  </div>
                )}

                {req.screenshotUrl && (
                  <div className="relative w-full max-w-[240px] aspect-video rounded-xl overflow-hidden border border-slate-800 bg-slate-950 group cursor-pointer"
                       onClick={() => window.open(req.screenshotUrl, '_blank')}>
                    <img src={req.screenshotUrl} alt="Proof" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                       <span className="text-[10px] font-bold text-white bg-slate-900/80 px-3 py-1.5 rounded-full border border-white/20">VIEW PROOF</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3">
              {req.status === 'pending' ? (
                <>
                  <Button variant="secondary" size="sm" className="text-rose-500" onClick={() => handleReject(req.id)}>
                    <X className="w-4 h-4 mr-2" /> Reject
                  </Button>
                  <Button variant="primary" size="sm" onClick={() => handleApprove(req)}>
                    <Check className="w-4 h-4 mr-2" /> Approve
                  </Button>
                </>
              ) : (
                <div className={cn(
                  "px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border",
                  req.status === 'approved' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" : "bg-red-500/10 border-red-500/20 text-red-500"
                )}>
                  {req.status}
                </div>
              )}
            </div>
          </Card>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-20 text-slate-600 border border-dashed border-slate-800 rounded-2xl">
            <Filter className="w-12 h-12 mx-auto mb-4 opacity-10" />
            <p>No {filter !== 'all' ? filter : ''} deposit requests found</p>
          </div>
        )}
      </div>
    </div>
  );
}
