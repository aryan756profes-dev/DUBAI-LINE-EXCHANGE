import { useState, useEffect } from 'react';
import { Card, Button, Modal } from '../../components/UI';
import { User, Shield, Search, Ban, CheckCircle, Wallet, AlertCircle } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, query, onSnapshot, doc, updateDoc, increment, serverTimestamp, orderBy, limit } from 'firebase/firestore';
import { formatCurrency, cn } from '../../lib/utils';

export default function AdminUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  
  // Balance Modal
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [adjustAmount, setAdjustAmount] = useState('');
  const [isAdjusting, setIsAdjusting] = useState(false);

  useEffect(() => {
    // Adding limit to prevent full collection fetch performance issue
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(150));
    const unsubscribe = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      // Gracefully handle if composite index is missing (creates index link in console natively via firebase core)
      if (error.code === 'failed-precondition') {
        const fallbackQ = query(collection(db, 'users'), limit(150));
        onSnapshot(fallbackQ, (snap2) => {
          setUsers(snap2.docs.map(doc => ({ id: doc.id, ...doc.data() })));
          setLoading(false);
        });
      } else {
        handleFirestoreError(error, OperationType.LIST, 'users');
      }
    });
    return () => unsubscribe();
  }, []);

  const handleAdjustBalance = async () => {
    if (!selectedUser || !adjustAmount || isNaN(Number(adjustAmount))) return;
    
    setIsAdjusting(true);
    try {
      const amount = Number(adjustAmount);
      const { runTransaction } = await import('firebase/firestore');
      const { computeUserFinancials } = await import('../../lib/utils');
      
      await runTransaction(db, async (transaction) => {
         const userRef = doc(db, 'users', selectedUser.id);
         const userSnap = await transaction.get(userRef);
         if (!userSnap.exists()) throw new Error("User not found");
         const userData = userSnap.data();
         
         const newBalance = (userData.balance || 0) + amount;
         const newRequiredWager = (userData.requiredWager || 0) + amount;
         const wagerCompleted = userData.wagerCompleted || 0;
         const newStats = computeUserFinancials(newBalance, newRequiredWager, wagerCompleted);

         transaction.update(userRef, {
           balance: newBalance,
           requiredWager: newRequiredWager,
           withdrawableAmount: newStats.withdrawableAmount,
           progressRatio: newStats.progressRatio,
           updatedAt: serverTimestamp()
         });
      });

      alert(`Successfully added ${formatCurrency(amount)} to ${selectedUser.username}`);
      setSelectedUser(null);
      setAdjustAmount('');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${selectedUser.id}`);
    } finally {
      setIsAdjusting(false);
    }
  };

  const handleRecalculateExposure = async () => {
    try {
      const { getDocs, where } = await import('firebase/firestore');
      setIsAdjusting(true);
      
      const betsQ = query(collection(db, 'bets'), where('status', '==', 'pending'));
      const betsSnap = await getDocs(betsQ);
      
      const userExposures: Record<string, number> = {};
      betsSnap.docs.forEach(bDoc => {
         const bData = bDoc.data();
         if (!userExposures[bData.userId]) userExposures[bData.userId] = 0;
         userExposures[bData.userId] += bData.amount;
      });

      for (const u of users) {
         const correctLocked = userExposures[u.id] || 0;
         if (u.lockedAmount !== correctLocked) {
             await updateDoc(doc(db, 'users', u.id), { lockedAmount: correctLocked });
         }
      }

      alert("Successfully recalculated exposure for all users!");
    } catch (error) {
      console.error(error);
      alert('Error recalculating exposure');
    } finally {
      setIsAdjusting(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.id.includes(searchTerm)
  );

  const toggleBlockStatus = async (userId: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        isBlocked: !currentStatus
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
    }
  };

  if (loading) return <div className="p-8 text-cyan-500 animate-pulse">Loading user repository...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">User Management</h1>
        <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={handleRecalculateExposure} loading={isAdjusting}>
               Recalculate Exposure
            </Button>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl py-2 pl-10 pr-4 text-sm text-white focus:border-cyan-500 outline-none w-full md:w-64"
              />
            </div>
        </div>
      </div>

      <div className="grid gap-4">
        {filteredUsers.map((user) => (
          <Card key={user.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group hover:border-slate-700 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-500">
                {(user.role === 'admin' || user.isAdmin) ? <Shield className="w-5 h-5" /> : <User className="w-5 h-5" />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white tracking-tight">{user.username}</h3>
                  {(user.role === 'admin' || user.isAdmin) && (
                    <span className="text-[9px] font-bold bg-cyan-500/10 text-cyan-500 px-2 py-0.5 rounded uppercase tracking-widest border border-cyan-500/20">Admin</span>
                  )}
                  {user.isBlocked && (
                    <span className="text-[9px] font-bold bg-red-500/10 text-red-500 px-2 py-0.5 rounded uppercase tracking-widest border border-red-500/20">Blocked</span>
                  )}
                </div>
                <p className="text-xs text-slate-500 truncate max-w-[200px]">{user.email}</p>
              </div>
            </div>

              <div className="flex items-center justify-between sm:justify-end gap-6 sm:gap-8 w-full sm:w-auto">
              <div className="text-right">
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-none mb-1">Exposure</p>
                <p className="text-sm font-bold text-rose-500 tabular-nums">{formatCurrency(user.lockedAmount || 0)}</p>
              </div>
              <div className="text-right">
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-none mb-1">Balance</p>
                <p className="text-base font-black text-emerald-500 tabular-nums">{formatCurrency(user.balance || 0)}</p>
                <p className="text-[8px] font-bold text-slate-600 uppercase tracking-tighter">Wager: {formatCurrency(user.wagerCompleted || 0)} / {formatCurrency(user.requiredWager || 0)}</p>
              </div>
              
              <div className="flex gap-2 shrink-0">
                <Button 
                   variant="secondary" 
                   size="sm" 
                   className="text-cyan-500"
                   onClick={() => setSelectedUser(user)}
                >
                  <Wallet className="w-4 h-4" />
                </Button>
                <Button 
                  variant="secondary" 
                  className={user.isBlocked ? "text-emerald-500" : "text-rose-500"} 
                  size="sm"
                  onClick={() => toggleBlockStatus(user.id, user.isBlocked)}
                >
                  {user.isBlocked ? <CheckCircle className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {filteredUsers.length === 0 && (
          <div className="text-center py-20 text-slate-600 border border-dashed border-slate-800 rounded-2xl">
            <User className="w-12 h-12 mx-auto mb-4 opacity-10" />
            <p>No users found matching your search</p>
          </div>
        )}
      </div>

      {/* Manual Balance Adjustment Modal */}
      <Modal 
        isOpen={!!selectedUser} 
        onClose={() => setSelectedUser(null)}
        title="Adjust User Balance"
      >
        <div className="space-y-6">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-4">
             <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-cyan-500">
                <User className="w-5 h-5" />
             </div>
             <div>
                <p className="text-xs font-bold text-white">{selectedUser?.username}</p>
                <p className="text-[10px] text-slate-500">{selectedUser?.email}</p>
             </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Amount to Add (or Subtract)</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
              <input 
                type="number"
                value={adjustAmount}
                onChange={(e) => setAdjustAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-8 pr-4 text-white focus:border-cyan-500 outline-none"
              />
            </div>
            <p className="text-[9px] text-slate-500 italic">Positive values will increase balance AND required wager. Negative values will decrease both.</p>
          </div>

          <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 flex gap-3">
             <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
             <p className="text-[10px] text-amber-200/80 leading-relaxed font-bold italic">
               NOTE: Adding balance manually will automatically increase the required wager (rollover) for this user to ensure platform security.
             </p>
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="secondary" className="flex-1" onClick={() => setSelectedUser(null)}>Cancel</Button>
            <Button 
              variant="primary" 
              className="flex-1" 
              loading={isAdjusting}
              disabled={!adjustAmount || isNaN(Number(adjustAmount))}
              onClick={handleAdjustBalance}
            >
              Update Balance
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
