import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, setDoc, deleteDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Card, Button } from '../../components/UI';
import { Gift, Plus, Trash2, Power, PowerOff, Edit2, X } from 'lucide-react';
import { format } from 'date-fns';

export default function AdminBonusCodes() {
  const [codes, setCodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [code, setCode] = useState('');
  const [amount, setAmount] = useState('');
  const [wagerMultiplier, setWagerMultiplier] = useState('1');
  const [usageLimit, setUsageLimit] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'bonusCodes'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setCodes(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !amount || !usageLimit) return alert('Fill all required fields');
    
    setCreating(true);
    try {
      const upperCode = code.trim().toUpperCase();
      const data: any = {
        code: upperCode,
        amount: Number(amount),
        wagerMultiplier: Number(wagerMultiplier) || 1,
        usageLimit: Number(usageLimit),
        isActive,
      };
      
      if (!editingId) {
        data.usedCount = 0;
        data.createdAt = serverTimestamp();
      }
      
      if (expiryDate) {
        data.expiry = new Date(expiryDate);
      }
      
      // If code changed during edit, we need to delete old one or just create a new code.
      // Easiest is to just use setDoc on `upperCode`. If editingId != upperCode, delete old code.
      if (editingId && editingId !== upperCode) {
        await deleteDoc(doc(db, 'bonusCodes', editingId));
      }

      await setDoc(doc(db, 'bonusCodes', upperCode), data, { merge: true });
      cancelEdit();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleEditStart = (c: any) => {
    setEditingId(c.id);
    setCode(c.code);
    setAmount(c.amount.toString());
    setWagerMultiplier(c.wagerMultiplier?.toString() || '1');
    setUsageLimit(c.usageLimit?.toString() || '');
    if (c.expiry) {
       // Convert firestore timestamp to local date string for input
       const d = c.expiry.toDate();
       // format for datetime-local: YYYY-MM-DDThh:mm
       const tzOffset = d.getTimezoneOffset() * 60000;
       const localISOTime = new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
       setExpiryDate(localISOTime);
    } else {
       setExpiryDate('');
    }
    setIsActive(c.isActive);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setCode('');
    setAmount('');
    setWagerMultiplier('1');
    setUsageLimit('');
    setExpiryDate('');
    setIsActive(true);
  };

  const toggleStatus = async (id: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'bonusCodes', id), {
        isActive: !currentStatus
      });
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this code? this action cannot be undone.')) return;
    try {
      await deleteDoc(doc(db, 'bonusCodes', id));
    } catch (err: any) {
      alert(err.message);
    }
  };

  if (loading) return <div className="text-white">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Gift className="w-6 h-6 text-cyan-500" /> Bonus Codes
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-1 border-slate-800 bg-slate-900/50 p-6 h-fit">
          <h2 className="text-lg font-bold text-white mb-4">{editingId ? 'Edit Code' : 'Create New Code'}</h2>
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase">Code</label>
              <input
                type="text"
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. WELCOME100"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 mt-1 text-white focus:border-cyan-500 outline-none uppercase"
                required
              />
            </div>
            
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase">Bonus Amount (₹)</label>
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="500"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 mt-1 text-white focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 uppercase">Wager Multiplier (x)</label>
              <input
                type="number"
                value={wagerMultiplier}
                onChange={e => setWagerMultiplier(e.target.value)}
                min="0"
                step="0.1"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 mt-1 text-white focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 uppercase">Usage Limit</label>
              <input
                type="number"
                value={usageLimit}
                onChange={e => setUsageLimit(e.target.value)}
                placeholder="100"
                min="1"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 mt-1 text-white focus:border-cyan-500 outline-none"
                required
              />
            </div>
            
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase">Expiry Date (Optional)</label>
              <input
                type="datetime-local"
                value={expiryDate}
                onChange={e => setExpiryDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 mt-1 text-white focus:border-cyan-500 outline-none"
              />
            </div>

            <div className="flex items-center gap-3 py-2">
              <input
                type="checkbox"
                id="isActive"
                checked={isActive}
                onChange={e => setIsActive(e.target.checked)}
                className="w-4 h-4 rounded border-slate-800 bg-slate-950 text-cyan-500"
              />
              <label htmlFor="isActive" className="text-sm font-bold text-slate-300 cursor-pointer">
                Status: Active
              </label>
            </div>

            <div className="flex items-center gap-2">
              <Button type="submit" loading={creating} className="flex-1" glow>
                {editingId ? <Edit2 className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />} 
                {editingId ? 'UPDATE CODE' : 'CREATE CODE'}
              </Button>
              {editingId && (
                <button type="button" onClick={cancelEdit} className="p-3 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
          </form>
        </Card>

        <Card className="col-span-1 lg:col-span-2 border-slate-800 bg-slate-900/50 p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase text-xs">
                <tr>
                  <th className="px-6 py-4">Code</th>
                  <th className="px-6 py-4">Amount</th>
                  <th className="px-6 py-4">Wager (x)</th>
                  <th className="px-6 py-4">Usage</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {codes.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-slate-500 italic">No bonus codes found</td>
                  </tr>
                ) : (
                  codes.map(c => (
                    <tr key={c.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 font-mono font-bold text-cyan-400">{c.code}</td>
                      <td className="px-6 py-4 font-bold text-emerald-400">₹{c.amount}</td>
                      <td className="px-6 py-4">{c.wagerMultiplier}x</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span>{c.usedCount || 0} / {c.usageLimit}</span>
                          <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-cyan-500"
                              style={{ width: `${Math.min(100, ((c.usedCount || 0) / c.usageLimit) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                          c.isActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-500'
                        }`}>
                          {c.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleEditStart(c)}
                            className="p-2 rounded-lg text-blue-500 hover:bg-blue-500/10 transition-colors"
                            title="Edit code"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => toggleStatus(c.id, c.isActive)}
                            className={`p-2 rounded-lg transition-colors ${
                              c.isActive ? 'text-amber-500 hover:bg-amber-500/10' : 'text-emerald-500 hover:bg-emerald-500/10'
                            }`}
                            title={c.isActive ? "Disable code" : "Enable code"}
                          >
                            {c.isActive ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => handleDelete(c.id)}
                            className="p-2 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors"
                            title="Delete code"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
